% This is the code to display the synthetic data used in 
% Active Learning with CHMMs
clear all
load data.mat
%
[dim,T,L] = size(data{1});
N_state = 3;
colordef black;
color = ['g' 'r' 'm' 'y' 'c' 'b' 'w' ];
% plot the data
figure
for target = 1:5
    X = data{target};
    for i = 1:L
        for t = 1:T
            plot(X(1,t,i),X(2,t,i),[color(target),'x'],'linewidth',2);
            hold on;
        end
    end
    disp('please enter any key!');
    pause;
end